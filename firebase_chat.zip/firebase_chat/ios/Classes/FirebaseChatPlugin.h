#import <Flutter/Flutter.h>

@interface FirebaseChatPlugin : NSObject<FlutterPlugin>
@end

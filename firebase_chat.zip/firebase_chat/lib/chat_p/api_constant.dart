const domainC = 'http://178.128.255.231:3001/'; //domain for image
const profileImageNotFoundC =
    'https://www.fulhamco.com/team_members/andrew-fulham/user-profile-not-found/#iLightbox[postimages]/0';
const imageNotFoundC =
    'https://user-images.githubusercontent.com/24848110/33519396-7e56363c-d79d-11e7-969b-09782f5ccbab.png';

const baseUrlDevC = 'http://178.128.255.231:3001/';
const baseUrlProC = 'http://178.128.255.231:3001/'; // Production API's
const userLoginApiC = 'users/login';
const userEditProfileApiC = 'users/editProfile';
const userEditPasswordApiC = 'users/changedPassword';
const notificationSentApiC = "app-notification";
const logoutApiC = 'users/logout';
const loginStatusApiC = 'users/login-status';

class ConstantC {
  static String baseUrl ; // Production API's  //Here 2 = production and one = develop
  static String notificationFullUrl ; // Production API's  //Here 2 = production and one = develop
  //Our server for development
}

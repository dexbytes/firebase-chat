class AppFonts {
  //String FontNameDefault = 'HelveticaNeue';
  String defaultFont = 'Precious';
//  String defaultFont = 'Gelion-Regular';
  String mediumFont = 'Gelion-Medium';
  String semiBoldFont = 'Gelion-SemiBold';
  String defaultFont2 = 'Roboto-Regular';
  String thinFont = 'HelveticaNeue-Thin';
  //String mediumFont = 'HelveticaNeue-Medium';
  String mainFont = 'HelveticaNeue';
  String largeFont = 'HelveticaNeue';
  String extraLargeFont = 'HelveticaNeue';
}
final appFonts = AppFonts();